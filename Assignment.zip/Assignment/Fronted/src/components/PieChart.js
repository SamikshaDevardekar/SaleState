import React, { useEffect, useState } from 'react';
import axios from '../services/api';
import { Pie } from 'react-chartjs-2';

const PieChart = ({ selectedMonth }) => {
  const [chartData, setChartData] = useState({});

  useEffect(() => {
    const fetchData = async () => {
      const { data } = await axios.get('/pie-chart', { params: { month: selectedMonth } });
      setChartData({
        labels: data.categories,
        datasets: [{
          label: 'Items per Category',
          data: data.itemCounts,
          backgroundColor: ['#FF6384', '#36A2EB', '#FFCE56']
        }]
      });
    };
    fetchData();
  }, [selectedMonth]);

  return <Pie data={chartData} />;
};

export default PieChart;
