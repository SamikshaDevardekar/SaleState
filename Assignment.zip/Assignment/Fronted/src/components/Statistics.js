import React, { useState, useEffect } from 'react';
import axios from '../services/api';

const Statistics = ({ selectedMonth }) => {
  const [statistics, setStatistics] = useState({});

  useEffect(() => {
    const fetchData = async () => {
      const { data } = await axios.get('/statistics', { params: { month: selectedMonth } });
      setStatistics(data);
    };
    fetchData();
  }, [selectedMonth]);

  return (
    <div>
      <h2>Statistics</h2>
      <p>Total Sale Amount: ${statistics.totalSaleAmount}</p>
      <p>Sold Items: {statistics.totalSoldItems}</p>
      <p>Not Sold Items: {statistics.totalNotSoldItems}</p>
    </div>
  );
};

export default Statistics;
