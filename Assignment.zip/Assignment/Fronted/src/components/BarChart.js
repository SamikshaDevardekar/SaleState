import React, { useEffect, useState } from 'react';
import axios from '../services/api';
import { Bar } from 'react-chartjs-2';

const BarChart = ({ selectedMonth }) => {
  const [chartData, setChartData] = useState({});

  useEffect(() => {
    const fetchData = async () => {
      const { data } = await axios.get('/bar-chart', { params: { month: selectedMonth } });
      setChartData({
        labels: data.priceRanges,
        datasets: [{
          label: 'Number of Items',
          data: data.itemCounts,
          backgroundColor: 'rgba(75,192,192,0.6)'
        }]
      });
    };
    fetchData();
  }, [selectedMonth]);

  return <Bar data={chartData} />;
};

export default BarChart;
