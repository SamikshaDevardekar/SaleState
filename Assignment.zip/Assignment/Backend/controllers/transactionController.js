const axios = require('axios');
const Transaction = require('../models/Transaction');

exports.initializeDatabase = async (req, res) => {
  try {
    const { data } = await axios.get('https://s3.amazonaws.com/roxiler.com/product_transaction.json');
    await Transaction.insertMany(data);
    res.json({ message: 'Database initialized' });
  } catch (error) {
    res.status(500).json({ message: 'Failed to initialize database', error });
  }
};

// Implement other methods like getTransactions, getStatistics, getBarChartData, getPieChartData, and getCombinedData with appropriate query logic and response formatting.
